#ifndef _ROSSERIAL_VEX_V5_HELLO_WORLD_H_
#define _ROSSERIAL_VEX_V5_HELLO_WORLD_H_

void setup();

#endif
